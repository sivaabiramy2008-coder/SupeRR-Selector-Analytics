# SupeRR Selector — Pressure Intelligence Dashboard

A multi-page Streamlit cricket analytics dashboard for the SupeRR Selector Season 2 pressure-performance challenge.

## Run on Windows
1. Install Python 3.10+.
2. Extract this ZIP folder.
3. Double-click `run_windows.bat` (or run the commands below).
4. Open the local URL Streamlit prints, usually `http://localhost:8501`.

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## Upload the official data
Use the left sidebar:
- **Ball-by-ball deliveries CSV** — required.
- **Matches / competition CSV** — optional, but recommended for target-score metadata.
- Expand **Column mapping** and verify that every field is mapped correctly. Required: match ID, innings, over, batter, bowler, runs off bat.

The dashboard has Overview, Pressure Lab, Batting Rankings, Bowling Rankings, Player Explorer, Match Tracker, Data Quality and Methodology pages. Ranking pages include player-profile navigation and CSV exports.

## Data and model cautions
- The built-in demo mode is **synthetic illustrative data only**. It exists to preview the interface. Never submit demo rankings as real findings.
- The model uses a transparent heuristic pressure index: chase required-rate stress (45), innings phase (30), wickets lost (25); high pressure is index >=65.
- Simplified 20-over assumption: 120 legal balls. Reduced-overs/DLS games require adjustments. First-innings pressure is an approximation.
- Check field mappings, source coverage, duplicate delivery keys, minimum samples and player eligibility before using rankings in a competition submission.
- Confirm official competition eligibility, player identity matching, and IPL/T20I format separation before final submission. This starter dashboard is not a substitute for validating the competition's supplied data and rules.

## Reference approaches consulted
- Streamlit multipage navigation concepts: https://docs.streamlit.io/develop/concepts/multipage-apps/overview
- IPL ball-by-ball analytics data modelling example: https://github.com/waquararshadkhan/ipl-analytics
- Cricsheet-style delivery field structure example: https://github.com/ritesh-ojha/IPL-DATASET

This is an independent educational analytics project, not affiliated with BCCI, IPL, or any tournament organizer.
