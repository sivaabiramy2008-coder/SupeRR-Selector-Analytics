import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from pathlib import Path

st.set_page_config(page_title='SupeRR | Pressure Intelligence', page_icon='🏏', layout='wide', initial_sidebar_state='expanded')

# ---------- Theme ----------
st.markdown('''<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');
html, body, [class*="css"] {font-family:'DM Sans',sans-serif;}
.stApp {background: radial-gradient(circle at 85% 0%, #162b4c 0%, #091321 34%, #07101c 72%); color:#eaf2ff;}
section[data-testid="stSidebar"] {background:linear-gradient(180deg,#0d1b2d,#091321); border-right:1px solid #203653;}
section[data-testid="stSidebar"] * {color:#eaf2ff !important;}
h1,h2,h3 {font-family:'Space Grotesk',sans-serif !important; letter-spacing:-.5px;}
.block-container {padding-top:1.5rem; padding-bottom:3rem; max-width:1500px;}
.hero {padding:28px 32px; border:1px solid #284565; border-radius:22px; background:linear-gradient(115deg,rgba(24,54,88,.95),rgba(10,24,42,.9)); box-shadow:0 18px 50px rgba(0,0,0,.22); margin-bottom:22px;}
.eyebrow {color:#48d9cf; font-size:12px; font-weight:700; letter-spacing:2px; text-transform:uppercase;}
.hero h1 {font-size:38px; margin:8px 0 4px; color:#f5f9ff;}
.hero p {color:#b9cbe0; margin:0; font-size:15px;}
.kpi {background:linear-gradient(145deg,#132942,#0d1d30); border:1px solid #25415f; border-radius:17px; padding:18px 20px; min-height:112px;}
.kpi-label {font-size:12px;color:#9eb4cd;text-transform:uppercase;letter-spacing:1px;font-weight:700;}
.kpi-value {font-family:'Space Grotesk';font-size:29px;font-weight:700;color:#f4f8ff;margin-top:8px;}
.kpi-sub {font-size:11px;color:#62d8c9;margin-top:3px;}
.panel {background:rgba(16,34,55,.76); border:1px solid #233e5c; border-radius:18px; padding:18px 20px;}
.muted {color:#9eb4cd;}
div[data-testid="stDataFrame"] {border:1px solid #25415f;border-radius:12px;overflow:hidden;}
.stButton>button {border-radius:10px;border:1px solid #2b5579;background:#143553;color:#f4f8ff;font-weight:700;}
.stButton>button:hover {border-color:#49d8ce;color:#49d8ce;}
[data-testid="stMetric"] {background:#10243a;padding:14px;border:1px solid #25415f;border-radius:14px;}
hr {border-color:#24415f;}
</style>''', unsafe_allow_html=True)

ALIASES = {
 'match_id':['match_id','matchid','id','game_id','match'], 'innings':['innings','inning','inn','innings_no'],
 'over':['over','overs','over_number'], 'ball':['ball','ball_number','delivery','ballnumber'],
 'batter':['batter','batsman','striker','player_batting'], 'bowler':['bowler','player_bowling'],
 'bat_runs':['batsman_runs','batter_runs','runs_off_bat','batsmanrun','bat_runs'],
 'total_runs':['total_runs','totalrun','runs','delivery_runs'], 'wicket':['is_wicket','iswicketdelivery','wicket','wickets','player_dismissed'],
 'wide':['wide_runs','wides','wide'], 'noball':['noball_runs','no_ball_runs','noballs','noball'],
 'season':['season','year','competition_season'], 'date':['date','match_date'], 'target':['target_runs','target','target_score'],
 'batting_team':['batting_team','battingteam','team_batting'], 'bowling_team':['bowling_team','bowlingteam','team_bowling']
}

def norm(s): return ''.join(ch.lower() for ch in str(s) if ch.isalnum())
def infer_col(cols, key):
    lookup={norm(c):c for c in cols}
    for a in ALIASES.get(key,[]):
        if norm(a) in lookup: return lookup[norm(a)]
    return None

def read_csv_upload(upload):
    if upload is None: return None
    try: return pd.read_csv(upload)
    except Exception:
        upload.seek(0)
        try: return pd.read_csv(upload, encoding='latin1')
        except Exception as e: st.error(f'Could not read {upload.name}: {e}'); return None

def card(label,value,sub=''):
    st.markdown(f'<div class="kpi"><div class="kpi-label">{label}</div><div class="kpi-value">{value}</div><div class="kpi-sub">{sub}</div></div>',unsafe_allow_html=True)

def page_header(kicker,title,desc):
    st.markdown(f'<div class="hero"><div class="eyebrow">{kicker}</div><h1>{title}</h1><p>{desc}</p></div>',unsafe_allow_html=True)

def make_demo():
    # Clearly labelled illustrative records; never used as competition evidence.
    rng=np.random.default_rng(17); rows=[]
    players=['A. Sharma','R. Iyer','K. Rahul','S. Gill','H. Pandya','S. Yadav','R. Jadeja','V. Kohli','J. Bumrah','M. Shami','Y. Chahal','A. Khan']
    bowlers=['J. Bumrah','M. Shami','Y. Chahal','A. Khan','H. Pandya','R. Jadeja']
    for m in range(1,31):
        for inn in [1,2]:
            bat_order=rng.permutation(players[:8]); bowl_order=rng.permutation(bowlers)
            total=0
            for ballno in range(120):
                ov=ballno//6; bat=bat_order[min(7,ballno//16)]; bowl=bowl_order[ov%len(bowl_order)]
                br=int(rng.choice([0,0,1,1,1,2,4,6],p=[.18,.12,.30,.10,.08,.12,.07,.03]))
                wk=int(rng.random()<.045); total+=br
                rows.append({'match_id':m,'innings':inn,'over':ov,'ball':ballno%6+1,'batter':bat,'bowler':bowl,'bat_runs':br,'total_runs':br,'wicket':wk,'wide':0,'noball':0,'season':2022+(m%4)})
    return pd.DataFrame(rows)

# ---------- Sidebar / data ingestion ----------
with st.sidebar:
    st.markdown('## 🏏 SupeRR')
    st.caption('PRESSURE INTELLIGENCE PLATFORM')
    st.markdown('---')
    st.markdown('### DATA CONTROL')
    delivery_file=st.file_uploader('Ball-by-ball deliveries CSV',type=['csv'],key='deliveries')
    match_file=st.file_uploader('Matches / competition CSV (optional)',type=['csv'],key='matches')
    demo=st.toggle('Load illustrative demo data',value=not bool(delivery_file),help='Demo records are synthetic and must never be submitted as real competition findings.')
    st.markdown('---')
    page=st.radio('NAVIGATION',['Overview','Pressure Lab','Batting Rankings','Bowling Rankings','Player Explorer','Match Tracker','Data Quality','Methodology'],index=0)
    st.markdown('---')
    st.caption('SupeRR Selector Season 2 • Round 1')

raw=read_csv_upload(delivery_file)
if raw is None and demo: raw=make_demo(); demo_mode=True
else: demo_mode=False
matches=read_csv_upload(match_file)
if raw is None:
    page_header('WELCOME / DATA WORKSPACE','Build your pressure picture.','Upload the official ball-by-ball CSV to unlock verified player rankings, match context and pressure trends.')
    st.info('Start by uploading the competition ball-by-ball deliveries CSV in the left sidebar. The dashboard will inspect the columns and build the analysis from your data.')
    st.markdown('### Expected workflow')
    st.write('**01 · Upload** official delivery data and optional match metadata → **02 · Map** columns → **03 · Validate** records → **04 · Analyse** pressure situations → **05 · Explore** player profiles and ranked lists.')
    st.stop()

# Map fields using detected aliases; allow user to override.
with st.sidebar.expander('⚙️ Column mapping',expanded=not demo_mode):
    st.caption('Auto-detected where possible. Change any field if your CSV uses different names.')
    mapped={}
    for key,label,required in [('match_id','Match ID',True),('innings','Innings',True),('over','Over number',True),('ball','Ball number',False),('batter','Batter name',True),('bowler','Bowler name',True),('bat_runs','Runs off bat',True),('total_runs','Total runs',False),('wicket','Wicket indicator / dismissed player',False),('wide','Wide runs',False),('noball','No-ball runs',False),('season','Season / year',False),('batting_team','Batting team',False),('bowling_team','Bowling team',False)]:
        guess=infer_col(raw.columns,key)
        opts=['— Not available —']+list(raw.columns)
        idx=opts.index(guess) if guess in opts else 0
        choice=st.selectbox(label,opts,index=idx,key='map_'+key)
        mapped[key]=None if choice.startswith('—') else choice
        if required and mapped[key] is None: st.warning(f'{label} is required for full analysis.')

missing=[k for k in ['match_id','innings','over','batter','bowler','bat_runs'] if mapped.get(k) is None]
if missing:
    st.error('Please map required fields in the sidebar: '+', '.join(missing)); st.stop()

df=pd.DataFrame()
for k,c in mapped.items():
    if c is not None: df[k]=raw[c]
for c in ['match_id','innings','over','bat_runs']:
    df[c]=pd.to_numeric(df[c],errors='coerce')
df=df.dropna(subset=['match_id','innings','over','batter','bowler','bat_runs']).copy()
df['innings']=df.innings.astype(int); df['over']=df.over.astype(int); df['bat_runs']=df.bat_runs.fillna(0)
if 'total_runs' not in df: df['total_runs']=df.bat_runs
else: df['total_runs']=pd.to_numeric(df.total_runs,errors='coerce').fillna(df.bat_runs)
for c in ['wide','noball']:
    if c not in df: df[c]=0
    else: df[c]=pd.to_numeric(df[c],errors='coerce').fillna(0)
if 'wicket' not in df: df['wicket']=0
# Interpret numeric wicket flags or non-empty dismissed-player values.
def wicket_flag(x):
    if pd.isna(x) or str(x).strip().lower() in ['', '0', '0.0', 'false', 'no', 'none', 'nan']: return 0
    if str(x).strip().lower() in ['1', '1.0', 'true', 'yes']: return 1
    # A non-empty dismissed-player name is treated as a wicket.
    return 1
# If a separate dismissed-player column is mapped as wicket, nonempty value means dismissal.
df['wicket']=df['wicket'].apply(wicket_flag)
df['legal_ball']=((df.wide==0)&(df.noball==0)).astype(int)
if 'ball' not in df: df['ball']=np.nan
df=df.sort_values(['match_id','innings','over'] + (['ball'] if 'ball' in df else [])).reset_index(drop=True)
df['runs_before']=df.groupby(['match_id','innings']).total_runs.cumsum()-df.total_runs
df['legal_before']=df.groupby(['match_id','innings']).legal_ball.cumsum()-df.legal_ball
df['wickets_before']=df.groupby(['match_id','innings']).wicket.cumsum()-df.wicket
df['legal_total']=df.groupby(['match_id','innings']).legal_ball.transform('sum')
df['balls_remaining']=(120-df.legal_before).clip(lower=0)
df['wickets_in_hand']=(10-df.wickets_before).clip(lower=0)
# derive chase targets from first innings totals; match target column overrides if available
first_totals=df[df.innings==1].groupby('match_id').total_runs.sum().add(1)
df['target']=df.match_id.map(first_totals)
# optional match target mapping
if matches is not None:
    mt=infer_col(matches.columns,'match_id'); tc=infer_col(matches.columns,'target')
    if mt and tc:
        target_map=pd.Series(pd.to_numeric(matches[tc],errors='coerce').values,index=matches[mt]).dropna().to_dict()
        df['target']=df.match_id.map(target_map).fillna(df.target)
# Pressure score for second-innings chase: RRR + innings phase + wickets lost. First innings uses phase + wickets lost.
remaining_runs=(df.target-df.runs_before).clip(lower=0)
df['required_rate']=np.where((df.innings>=2)&df.target.notna()&(df.balls_remaining>0),remaining_runs*6/df.balls_remaining,np.nan)
rr_component=np.clip((df.required_rate.fillna(7)-6)/12,0,1)*45
phase_component=np.clip((df.legal_before/120),0,1)*30
wicket_component=np.clip((10-df.wickets_in_hand)/8,0,1)*25
df['pressure_score']=np.clip(rr_component+phase_component+wicket_component,0,100).round(1)
df['pressure_band']=pd.cut(df.pressure_score,[-1,34,64,100],labels=['LOW','MEDIUM','HIGH'])
df['season_label']=df['season'].astype(str) if 'season' in df else 'All available seasons'

# Batting and bowling aggregates
min_balls=st.sidebar.slider('Minimum balls faced (ranking eligibility)',10,120,30,5)
min_balls_bowl=st.sidebar.slider('Minimum legal balls bowled',12,120,24,6)
pressure=df[df.pressure_score>=65].copy()
league_sr=(df.bat_runs.sum()/max(1,df.legal_ball.sum()))*100
bat=df.groupby('batter').agg(runs=('bat_runs','sum'),balls=('legal_ball','sum'),dismissals=('wicket','sum'),fours=('bat_runs',lambda s:(s==4).sum()),sixes=('bat_runs',lambda s:(s==6).sum()),matches=('match_id','nunique'),avg_pressure=('pressure_score','mean')).reset_index()
bat['strike_rate']=100*bat.runs/bat.balls.replace(0,np.nan)
bat['average']=bat.runs/bat.dismissals.replace(0,np.nan)
bat['boundary_pct']=100*(bat.fours+bat.sixes)/bat.balls.replace(0,np.nan)
bp=pressure.groupby('batter').agg(pressure_runs=('bat_runs','sum'),pressure_balls=('legal_ball','sum'),pressure_dismissals=('wicket','sum'),pressure_matches=('match_id','nunique')).reset_index()
bat=bat.merge(bp,on='batter',how='left').fillna({'pressure_runs':0,'pressure_balls':0,'pressure_dismissals':0,'pressure_matches':0})
bat['pressure_sr']=100*bat.pressure_runs/bat.pressure_balls.replace(0,np.nan)
bat['sr_vs_league']=bat.pressure_sr/max(league_sr,1)*100
bat['dismissal_rate']=bat.pressure_dismissals/bat.pressure_balls.replace(0,np.nan)
bat['reliability_score']=(0.45*bat.sr_vs_league.fillna(0).clip(0,160)/1.6 + 0.25*(bat.pressure_runs/(bat.pressure_runs+20))*100 + 0.20*(1-bat.dismissal_rate.fillna(0).clip(0,1))*100 + 0.10*(bat.pressure_matches.clip(upper=10)/10)*100).clip(0,100).round(1)
bat['eligible']=(bat.balls>=min_balls)&(bat.pressure_balls>=12)
bat_rank=bat[bat.eligible].sort_values(['reliability_score','pressure_runs'],ascending=False).reset_index(drop=True)
bat_rank.insert(0,'Rank',range(1,len(bat_rank)+1))

legal_bowls=df[df.legal_ball==1].copy()
bowl=legal_bowls.groupby('bowler').agg(legal_balls=('legal_ball','sum'),conceded=('total_runs','sum'),wickets=('wicket','sum'),matches=('match_id','nunique'),avg_pressure=('pressure_score','mean')).reset_index()
bowl['overs']=bowl.legal_balls/6
bowl['economy']=bowl.conceded/bowl.overs.replace(0,np.nan)
bowl['wicket_rate']=6*bowl.wickets/bowl.legal_balls.replace(0,np.nan)
pb=legal_bowls[legal_bowls.pressure_score>=65].groupby('bowler').agg(p_balls=('legal_ball','sum'),p_runs=('total_runs','sum'),p_wickets=('wicket','sum'),p_matches=('match_id','nunique')).reset_index()
bowl=bowl.merge(pb,on='bowler',how='left').fillna({'p_balls':0,'p_runs':0,'p_wickets':0,'p_matches':0})
bowl['pressure_economy']=6*bowl.p_runs/bowl.p_balls.replace(0,np.nan)
base_econ=legal_bowls.total_runs.sum()/max(1,legal_bowls.legal_ball.sum())*6
bowl['econ_advantage']=(base_econ-bowl.pressure_economy)/max(base_econ,1)*100
bowl['reliability_score']=(0.40*bowl.econ_advantage.fillna(0).clip(-50,50).add(50) + 0.30*(bowl.p_wickets/(bowl.p_balls/6).replace(0,np.nan)).fillna(0).clip(0,3)/3*100 + 0.20*(bowl.p_matches.clip(upper=10)/10)*100 + 0.10*(bowl.legal_balls.clip(upper=120)/120)*100).clip(0,100).round(1)
bowl['eligible']=(bowl.legal_balls>=min_balls_bowl)&(bowl.p_balls>=12)
bowl_rank=bowl[bowl.eligible].sort_values(['reliability_score','p_wickets'],ascending=False).reset_index(drop=True)
bowl_rank.insert(0,'Rank',range(1,len(bowl_rank)+1))

# Global filters
with st.sidebar:
    seasons=sorted(df.season_label.astype(str).unique().tolist())
    season_filter=st.multiselect('Season filter',seasons,default=seasons)
filtered=df[df.season_label.astype(str).isin(season_filter)] if season_filter else df.iloc[0:0]

# ---------- Views ----------
if page=='Overview':
    page_header('MATCH INTELLIGENCE / OVERVIEW','Pressure, measured. Decisions, clearer.','A data-led command centre for identifying players who deliver when match conditions become demanding.')
    if demo_mode: st.warning('ILLUSTRATIVE DEMO MODE — synthetic sample data is shown for interface preview only. Upload official competition CSVs before using any ranking as evidence.')
    c1,c2,c3,c4=st.columns(4)
    with c1: card('DELIVERIES PROCESSED',f'{len(df):,}','Rows after validation')
    with c2: card('MATCHES TRACKED',f'{df.match_id.nunique():,}','Unique match IDs')
    with c3: card('PLAYERS IDENTIFIED',f'{pd.concat([df.batter,df.bowler]).nunique():,}','Batters + bowlers')
    with c4: card('HIGH-PRESSURE BALLS',f'{(df.pressure_score>=65).sum():,}',f'{100*(df.pressure_score>=65).mean():.1f}% of deliveries')
    st.markdown('### Performance pulse')
    a,b=st.columns([1.45,1])
    with a:
        trend=df.groupby('over').agg(avg_pressure=('pressure_score','mean'),runs=('total_runs','mean')).reset_index()
        fig=px.area(trend,x='over',y='avg_pressure',markers=True,title='Pressure intensity by over',labels={'over':'Over','avg_pressure':'Average pressure index'})
        fig.update_traces(line_color='#4bd8ce',fillcolor='rgba(75,216,206,.14)'); fig.update_layout(paper_bgcolor='rgba(0,0,0,0)',plot_bgcolor='rgba(0,0,0,0)',font_color='#dceaff',title_font_color='#f3f8ff',margin=dict(l=10,r=10,t=50,b=10)); st.plotly_chart(fig,use_container_width=True)
    with b:
        bands=df.pressure_band.value_counts().reindex(['LOW','MEDIUM','HIGH']).fillna(0).reset_index(); bands.columns=['Pressure band','Deliveries']
        fig=px.pie(bands,names='Pressure band',values='Deliveries',hole=.68,title='Pressure distribution'); fig.update_layout(paper_bgcolor='rgba(0,0,0,0)',font_color='#dceaff',legend_title_text='',margin=dict(l=5,r=5,t=50,b=5)); st.plotly_chart(fig,use_container_width=True)
    st.markdown('### Leaderboard snapshot')
    x,y=st.columns(2)
    with x: st.markdown('**Top pressure batters**'); st.dataframe(bat_rank[['Rank','batter','reliability_score','pressure_runs','pressure_sr']].head(5),hide_index=True,use_container_width=True)
    with y: st.markdown('**Top pressure bowlers**'); st.dataframe(bowl_rank[['Rank','bowler','reliability_score','p_wickets','pressure_economy']].head(5),hide_index=True,use_container_width=True)
    st.caption('Rankings are computed from the uploaded data and current eligibility thresholds. See Methodology for definitions and caveats.')

elif page=='Pressure Lab':
    page_header('ANALYTICS ENGINE / PRESSURE LAB','Explore the pressure curve.','Filter the match state, inspect high-pressure spells and understand what drives the pressure index.')
    f1,f2,f3=st.columns(3)
    with f1: band=st.selectbox('Pressure band',['All','LOW','MEDIUM','HIGH'])
    with f2: innings_pick=st.selectbox('Innings',['All']+sorted(df.innings.unique().tolist()))
    with f3: over_range=st.slider('Over range',0,19,(0,19))
    q=df[(df.over>=over_range[0])&(df.over<=over_range[1])]
    if band!='All': q=q[q.pressure_band.astype(str)==band]
    if innings_pick!='All': q=q[q.innings==innings_pick]
    m1,m2,m3=st.columns(3)
    with m1: card('FILTERED DELIVERIES',f'{len(q):,}')
    with m2: card('AVG PRESSURE',f'{q.pressure_score.mean():.1f}' if len(q) else '—','0–100 index')
    with m3: card('RUNS SCORED',f'{q.total_runs.sum():,}')
    fig=px.scatter(q,x='over',y='pressure_score',color='pressure_band',hover_data=['match_id','innings','batter','bowler','total_runs'],title='Delivery-level pressure map',opacity=.7); fig.update_layout(paper_bgcolor='rgba(0,0,0,0)',plot_bgcolor='rgba(0,0,0,0)',font_color='#dceaff'); st.plotly_chart(fig,use_container_width=True)
    st.markdown('### Highest-pressure deliveries'); st.dataframe(q.sort_values('pressure_score',ascending=False)[['match_id','innings','over','batter','bowler','total_runs','wicket','required_rate','pressure_score']].head(30),hide_index=True,use_container_width=True)

elif page=='Batting Rankings':
    page_header('PLAYER INTELLIGENCE / BATTERS','Batters who stand up under pressure.','A transparent, sample-aware ranking based on pressure-phase output and consistency indicators.')
    if demo_mode: st.warning('Synthetic demo data only. Upload the official data pack before treating this leaderboard as competition results.')
    st.caption(f'Eligibility: at least {min_balls} total balls and 12 high-pressure balls. Score is a composite indicator, not an official cricket rating.')
    st.dataframe(bat_rank[['Rank','batter','reliability_score','pressure_runs','pressure_balls','pressure_sr','average','matches','pressure_matches']].head(50),hide_index=True,use_container_width=True)
    if len(bat_rank):
        chosen=st.selectbox('Open batter profile',bat_rank.batter.tolist(),key='bat_profile')
        if st.button('↗ Open selected batter details',use_container_width=True): st.session_state['selected_player']=chosen; st.session_state['selected_role']='Batter'; st.session_state['nav_target']='Player Explorer'; st.rerun()
    st.download_button('⬇ Download batter ranking CSV',bat_rank.to_csv(index=False).encode('utf-8'),file_name='supeRR_batter_rankings.csv',mime='text/csv')

elif page=='Bowling Rankings':
    page_header('PLAYER INTELLIGENCE / BOWLERS','Bowlers built for pressure overs.','Evaluate pressure economy, wicket impact and the volume of evidence behind each player.')
    if demo_mode: st.warning('Synthetic demo data only. Upload the official data pack before treating this leaderboard as competition results.')
    st.caption(f'Eligibility: at least {min_balls_bowl} legal balls and 12 high-pressure balls. Lower pressure economy is better.')
    st.dataframe(bowl_rank[['Rank','bowler','reliability_score','p_wickets','p_balls','pressure_economy','economy','matches','p_matches']].head(50),hide_index=True,use_container_width=True)
    if len(bowl_rank):
        chosen=st.selectbox('Open bowler profile',bowl_rank.bowler.tolist(),key='bowl_profile')
        if st.button('↗ Open selected bowler details',use_container_width=True): st.session_state['selected_player']=chosen; st.session_state['selected_role']='Bowler'; st.session_state['nav_target']='Player Explorer'; st.rerun()
    st.download_button('⬇ Download bowler ranking CSV',bowl_rank.to_csv(index=False).encode('utf-8'),file_name='supeRR_bowler_rankings.csv',mime='text/csv')

elif page=='Player Explorer':
    page_header('PLAYER INTELLIGENCE / PLAYER EXPLORER','One player. Every pressure moment.','Select a player to open their performance profile, pressure trend, match sample and key indicators.')
    all_players=sorted(set(df.batter.dropna().astype(str))|set(df.bowler.dropna().astype(str)))
    default=st.session_state.get('selected_player',all_players[0] if all_players else '')
    player=st.selectbox('Select player',all_players,index=all_players.index(default) if default in all_players else 0)
    role=st.radio('Role lens',['Batting','Bowling'],horizontal=True)
    if role=='Batting':
        p=df[df.batter.astype(str)==player]; runs=p.bat_runs.sum(); balls=p.legal_ball.sum(); dismissals=p.wicket.sum(); sr=100*runs/max(1,balls); avg=runs/max(1,dismissals); hi=p[p.pressure_score>=65]
        a,b,c,d=st.columns(4)
        with a: card('RUNS',f'{runs:,}')
        with b: card('STRIKE RATE',f'{sr:.1f}')
        with c: card('AVERAGE',f'{avg:.1f}')
        with d: card('PRESSURE RUNS',f'{hi.bat_runs.sum():,}')
        per=p.groupby('over').agg(runs=('bat_runs','sum'),balls=('legal_ball','sum'),pressure=('pressure_score','mean')).reset_index(); per['strike_rate']=100*per.runs/per.balls.replace(0,np.nan)
        fig=px.line(per,x='over',y='strike_rate',markers=True,title=f'{player} · scoring rate by over'); fig.update_traces(line_color='#4bd8ce'); fig.update_layout(paper_bgcolor='rgba(0,0,0,0)',plot_bgcolor='rgba(0,0,0,0)',font_color='#dceaff'); st.plotly_chart(fig,use_container_width=True)
        st.markdown('**Pressure innings / delivery log**'); st.dataframe(hi[['match_id','innings','over','total_runs','wicket','pressure_score']].head(100),hide_index=True,use_container_width=True)
    else:
        p=df[df.bowler.astype(str)==player]; legal=p[p.legal_ball==1]; conceded=legal.total_runs.sum(); wickets=legal.wicket.sum(); overs=len(legal)/6; econ=conceded/max(overs,1/6); hi=legal[legal.pressure_score>=65]
        a,b,c,d=st.columns(4)
        with a: card('LEGAL BALLS',f'{len(legal):,}')
        with b: card('ECONOMY',f'{econ:.2f}')
        with c: card('WICKETS',f'{wickets:,}')
        with d: card('PRESSURE WICKETS',f'{hi.wicket.sum():,}')
        per=legal.groupby('over').agg(runs=('total_runs','sum'),balls=('legal_ball','sum'),wickets=('wicket','sum')).reset_index(); per['economy']=6*per.runs/per.balls.replace(0,np.nan)
        fig=px.line(per,x='over',y='economy',markers=True,title=f'{player} · economy by over'); fig.update_traces(line_color='#f6b85c'); fig.update_layout(paper_bgcolor='rgba(0,0,0,0)',plot_bgcolor='rgba(0,0,0,0)',font_color='#dceaff'); st.plotly_chart(fig,use_container_width=True)
        st.markdown('**Pressure spell / delivery log**'); st.dataframe(hi[['match_id','innings','over','total_runs','wicket','pressure_score']].head(100),hide_index=True,use_container_width=True)

elif page=='Match Tracker':
    page_header('LIVE-STYLE WORKSPACE / MATCH TRACKER','Follow the match state.','Explore any match in the uploaded historical dataset ball by ball. This is historical-data tracking, not a live score feed.')
    ids=sorted(df.match_id.dropna().unique().tolist())
    match_id=st.selectbox('Choose match ID',ids)
    md=df[df.match_id==match_id].copy()
    st.markdown(f'### Match {match_id} · {md.innings.nunique()} innings found')
    summary=md.groupby('innings').agg(runs=('total_runs','sum'),wickets=('wicket','sum'),deliveries=('legal_ball','sum')).reset_index(); summary['overs']=summary.deliveries/6
    st.dataframe(summary,use_container_width=True,hide_index=True)
    fig=px.line(md.groupby(['innings','over']).agg(runs=('total_runs','sum')).reset_index(),x='over',y='runs',color='innings',markers=True,title='Runs by over'); fig.update_layout(paper_bgcolor='rgba(0,0,0,0)',plot_bgcolor='rgba(0,0,0,0)',font_color='#dceaff'); st.plotly_chart(fig,use_container_width=True)
    st.markdown('### Ball-by-ball timeline'); st.dataframe(md[['innings','over','ball','batter','bowler','bat_runs','total_runs','wicket','pressure_score']].head(250),hide_index=True,use_container_width=True)

elif page=='Data Quality':
    page_header('TRUST / DATA QUALITY','Know what went into the model.','Inspect missing values, duplicate deliveries, field coverage and the size of the evidence base.')
    raw_rows=len(raw); clean_rows=len(df); dupes=int(df.duplicated(subset=['match_id','innings','over']+(['ball'] if 'ball' in df else [])).sum())
    a,b,c,d=st.columns(4)
    with a: card('RAW ROWS',f'{raw_rows:,}')
    with b: card('USABLE ROWS',f'{clean_rows:,}')
    with c: card('DUPLICATE KEY ROWS',f'{dupes:,}')
    with d: card('ROWS RETAINED',f'{100*clean_rows/max(1,raw_rows):.1f}%')
    quality=pd.DataFrame({'Field':raw.columns,'Missing values':[int(raw[c].isna().sum()) for c in raw.columns],'Missing %':[round(100*raw[c].isna().mean(),2) for c in raw.columns],'Data type':[str(raw[c].dtype) for c in raw.columns]})
    st.markdown('### Source field audit'); st.dataframe(quality,hide_index=True,use_container_width=True)
    st.markdown('### Validation notes')
    st.write('- Required fields are mapped in the sidebar; rows missing required values are excluded.\n- Wides and no-balls are excluded from legal-ball counts when those columns are mapped.\n- If target score is unavailable, chase target is derived from first-innings total + 1.\n- Missing extras or wicket fields reduce the reliability of derived metrics; check the source mapping.')

elif page=='Methodology':
    page_header('MODEL TRANSPARENCY / METHODOLOGY','A score you can explain.','The dashboard makes the pressure definition visible so rankings can be challenged, checked and reproduced.')
    st.markdown('### Pressure definition')
    st.write('A delivery is treated as high pressure when the composite pressure index is **65 or above**. The index is a heuristic match-state score from 0–100, not a trained probability model.')
    st.markdown('### Pressure index components')
    components=pd.DataFrame({'Component':['Required run-rate stress (chase)','Innings phase','Wickets lost'],'Weight / maximum':['45 points','30 points','25 points'],'Interpretation':['Higher required rate increases pressure','Later overs increase pressure','Fewer wickets in hand increase pressure']})
    st.dataframe(components,hide_index=True,use_container_width=True)
    st.markdown('### Player scoring')
    st.write('**Batters:** pressure strike-rate relative to the dataset baseline, pressure runs/sample, dismissal rate and pressure-match coverage. **Bowlers:** pressure economy advantage versus the dataset baseline, pressure wicket rate, pressure-match coverage and legal-ball volume. Minimum sample thresholds are adjustable in the sidebar.')
    st.markdown('### Important limitations')
    st.write('- This first-pass model uses a simplified 20-over innings assumption (120 legal balls). Shortened or rain-affected games need innings-length/DLS adjustment.\n- First-innings pressure is estimated from innings phase and wickets lost; a richer model should add required par score and match closeness.\n- If ball number, wides/no-balls, dismissal type, target, or playing-XI data are missing, some metrics are approximate.\n- Comparisons should be stratified by format, competition, season, role and sample size where the official dataset permits.\n- Rankings are only as reliable as source coverage and column mapping. Validate top candidates against source scorecards before submission.')
    st.markdown('### Reproducibility')
    st.write('Upload the same CSVs, keep the same column mappings and eligibility thresholds, and the analysis will reproduce the same leaderboard. Export the ranking CSVs from the ranking pages for audit.')

# Global footer
st.markdown('---')
st.caption('SupeRR Selector Analytics • Built for transparent historical pressure analysis • Not affiliated with any cricket board or league.')
